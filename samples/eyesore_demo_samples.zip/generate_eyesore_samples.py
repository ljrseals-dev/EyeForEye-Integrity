#!/usr/bin/env python3
"""Generate demonstration audio samples for the Eyesore project.

Creates simple tones and processed variants that illustrate:
- Clean generated audio (as from a local voice/sample source)
- Pitch shifting, via a duration-preserving phase vocoder
- Offline vocal-style compression (concept of eyesore_audio.compress_vocal)

The phase vocoder here is a self-contained Python port of the *behaviour*
of Eyesore's C++ `PitchShifter::shift` — not bit-identical to the C++
output, but sufficient to verify the duration-preserving property and to
give a listenable demo file.

Run:
    python3 generate_eyesore_samples.py
Outputs to: /home/workdir/artifacts/eyesore_samples/
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
from scipy.io import wavfile

OUT_DIR = Path("/home/workdir/artifacts/eyesore_samples")
OUT_DIR.mkdir(parents=True, exist_ok=True)
SR = 44100
TARGET_PEAK = 0.89
CEILING = 0.999


# ---------- I/O with honest gain staging ---------------------------------

def write_wav(name, audio, sr=SR, gain=None):
    """Write a WAV.

    If `gain` is None, normalize to TARGET_PEAK and return the applied gain.
    If `gain` is given (e.g. the raw file's gain, for an A/B pair), apply it
    as-is — no renormalization — so the effect of the processing survives.
    A hard ceiling prevents clipping; if it engages, it prints a note.
    """
    audio = np.asarray(audio, dtype=np.float64)
    peak = float(np.max(np.abs(audio))) if audio.size else 0.0
    if gain is None:
        gain = (TARGET_PEAK / peak) if peak > 0 else 1.0
    if peak > 0 and peak * gain > CEILING:
        reduced = CEILING / peak
        print(f"  [clamp] {name}: gain {20*np.log10(gain):+.1f} -> {20*np.log10(reduced):+.1f} dB")
        gain = reduced
    out = (audio * gain).astype(np.float32)
    path = OUT_DIR / name
    # scipy expects int16 or float32 in [-1, 1]
    wavfile.write(str(path), sr, out)
    peak_db = 20 * np.log10(max(float(np.max(np.abs(out))), 1e-9))
    print(f"  {path.name}  ({len(out)/sr:.2f}s, peak {peak_db:+.1f} dBFS)")
    return gain


def write_pair(raw_name, raw, comp_name, comp, sr=SR):
    """Write raw and compressed as a level-matched A/B pair.

    Both files share a single gain, computed from the raw file. This is the
    only way the compressed file's *lower dynamic range* is audible in the
    A/B — renormalizing it would throw the compressor's work away.
    """
    peak_raw = float(np.max(np.abs(raw)))
    peak_comp = float(np.max(np.abs(comp)))
    gain = (TARGET_PEAK / peak_raw) if peak_raw > 0 else 1.0
    if peak_comp * gain > CEILING:
        old = gain
        gain = CEILING / peak_comp
        print(f"  [note] compressor raised peak above ceiling; "
              f"scaling both by {20*np.log10(gain/old):+.1f} dB")
    write_wav(raw_name, raw, sr, gain=gain)
    write_wav(comp_name, comp, sr, gain=gain)
    return gain


# ---------- Synthesis -----------------------------------------------------

def sine(freq, duration, sr=SR, amp=0.5):
    t = np.arange(int(sr * duration)) / sr
    return amp * np.sin(2 * np.pi * freq * t)


def tone_with_harmonics(freq, duration, sr=SR, amp=0.4):
    """Fundamental plus a few harmonics, with a short attack/release."""
    t = np.arange(int(sr * duration)) / sr
    sig = (
        1.00 * np.sin(2 * np.pi * freq * t)
        + 0.45 * np.sin(2 * np.pi * 2 * freq * t)
        + 0.25 * np.sin(2 * np.pi * 3 * freq * t)
        + 0.12 * np.sin(2 * np.pi * 4 * freq * t)
    )
    attack = int(0.03 * sr)
    release = int(0.08 * sr)
    env = np.ones_like(sig)
    env[:attack] = np.linspace(0, 1, attack)
    env[-release:] = np.linspace(1, 0, release)
    return amp * sig * env


def vocalish(sr=SR, duration=2.5):
    """A swept, vibrato-ish tone.

    Phase is accumulated via cumsum, so the instantaneous frequency is
    exactly the intended sweep — not the drifting, amplitude-growing artifact
    you get from the naive sin(2*pi*f(t)*t) form.
    """
    n = int(sr * duration)
    t = np.arange(n) / sr
    inst_freq = 180.0 + 40.0 * np.sin(2 * np.pi * 3.5 * t)  # 140..220 Hz
    phase = 2 * np.pi * np.cumsum(inst_freq) / sr
    sig = (
        0.55 * np.sin(phase)
        + 0.30 * np.sin(2 * phase)
        + 0.15 * np.sin(3 * phase)
    )
    env = np.ones(n)
    a = int(0.08 * sr)
    r = int(0.25 * sr)
    env[:a] = np.linspace(0, 1, a)
    env[-r:] = np.linspace(1, 0, r)
    return 0.55 * sig * env


# ---------- Compressor (faithful to eyesore_audio.compress_vocal) --------

def simple_feedforward_compressor(
    x, sr,
    threshold_db=-18.0, ratio=3.0,
    attack_ms=10.0, release_ms=100.0,
    makeup_db=2.0, max_reduction_db=12.0,
):
    """Feed-forward compressor with a sample-peak ceiling at CEILING.

    The ceiling is faithful to the repo's compress_vocal; it only fires on
    extreme input, and if it does, a note is printed. For demo material the
    interesting work happens in the envelope follower, not the ceiling.
    """
    x = np.asarray(x, dtype=np.float64)
    attack = np.exp(-1 / (sr * attack_ms / 1000))
    release = np.exp(-1 / (sr * release_ms / 1000))
    makeup = 10 ** (makeup_db / 20)
    env = 0.0
    gain = 1.0
    out = np.empty_like(x)
    for i in range(x.size):
        level = abs(float(x[i]))
        c_env = attack if level > env else release
        env = c_env * env + (1 - c_env) * level
        over = max(0.0, 20 * np.log10(max(env, 1e-8)) - threshold_db)
        reduction = min(max_reduction_db, over * (1 - 1 / ratio))
        target = 10 ** (-reduction / 20)
        c_gain = attack if target < gain else release
        gain = c_gain * gain + (1 - c_gain) * target
        out[i] = x[i] * gain * makeup
    peak = float(np.max(np.abs(out)))
    if peak > CEILING:
        out *= CEILING / peak
        print(f"    (compressor peak ceiling engaged: "
              f"{20*np.log10(peak):+.1f} -> {20*np.log10(CEILING):+.1f} dBFS)")
    return out


# ---------- Duration-preserving pitch shift (phase vocoder port) ---------

def _phase_vocoder_stretch(x, stretch, n_fft=2048, hop=512):
    """Time-stretch by `stretch` (stretch > 1 => longer).

    Per-bin phase advance, magnitude interpolation between source frames.
    Output length is quantized to the STFT frame grid.
    """
    win = np.hanning(n_fft)
    if len(x) < n_fft:
        x = np.pad(x, (0, n_fft - len(x)))
    n_frames = 1 + (len(x) - n_fft) // hop
    if n_frames < 2:
        return np.asarray(x, dtype=np.float64)

    specs = np.empty((n_frames, n_fft // 2 + 1), dtype=complex)
    for i in range(n_frames):
        seg = x[i * hop: i * hop + n_fft] * win
        specs[i] = np.fft.rfft(seg)
    mags = np.abs(specs)
    phases = np.angle(specs)

    bins = np.arange(n_fft // 2 + 1)
    omega = 2 * np.pi * hop * bins / n_fft  # expected phase advance per hop

    out_frames = max(2, int(round(n_frames * stretch)))
    out_specs = np.empty((out_frames, n_fft // 2 + 1), dtype=complex)
    phase_acc = phases[0].copy()
    out_specs[0] = mags[0] * np.exp(1j * phase_acc)

    for i in range(1, out_frames):
        src = min(i / stretch, n_frames - 1 - 1e-9)
        i0 = int(src)
        frac = src - i0
        i1 = min(i0 + 1, n_frames - 1)
        mag = (1 - frac) * mags[i0] + frac * mags[i1]
        if i0 > 0:
            dphi = phases[i0] - phases[i0 - 1]
        else:
            dphi = np.zeros_like(omega)
        dphi = dphi - omega
        dphi = (dphi + np.pi) % (2 * np.pi) - np.pi
        phase_acc = phase_acc + (omega + dphi)
        out_specs[i] = mag * np.exp(1j * phase_acc)

    out_len = (out_frames - 1) * hop + n_fft
    y = np.zeros(out_len)
    wsum = np.zeros(out_len)
    for i in range(out_frames):
        frame = np.fft.irfft(out_specs[i], n_fft) * win
        y[i * hop: i * hop + n_fft] += frame
        wsum[i * hop: i * hop + n_fft] += win ** 2
    return y / np.maximum(wsum, 1e-8)


def pitch_shift(x, ratio, n_fft=2048, hop=512):
    """Duration-preserving pitch shift by `ratio` (2.0 == +1 octave).

    Standard recipe: time-stretch by `ratio`, then linearly resample back to
    the original length. Length in == length out, pitch multiplied by ratio.
    """
    x = np.asarray(x, dtype=np.float64)
    stretched = _phase_vocoder_stretch(x, ratio, n_fft=n_fft, hop=hop)
    target_len = len(x)
    if target_len == 0:
        return x.copy()
    src_pos = np.linspace(0, len(stretched) - 1, target_len)
    return np.interp(src_pos, np.arange(len(stretched)), stretched)


def dominant_freq(x, sr=SR):
    """Dominant spectral peak in Hz — reliable for a clean harmonic tone."""
    x = np.asarray(x, dtype=np.float64)
    n = len(x)
    if n < 8:
        return 0.0
    spec = np.abs(np.fft.rfft(x * np.hanning(n)))
    spec[0] = 0.0
    freqs = np.fft.rfftfreq(n, 1 / sr)
    return float(freqs[int(np.argmax(spec))])


# ---------- Main ----------------------------------------------------------

def main():
    print(f"Writing to {OUT_DIR}\n")

    print("Baseline tones")
    write_wav("01_original_440Hz_sine.wav", sine(440, 2.0))

    rich = tone_with_harmonics(440, 2.2)
    comp_rich = simple_feedforward_compressor(rich, SR)
    write_pair(
        "02_original_440Hz_rich.wav", rich,
        "06_compressed_440Hz_rich.wav", comp_rich,
    )

    print("\nPitch-shifted (synthesized at target pitch — not round-tripped)")
    write_wav("03_pitch_up_octave_880Hz.wav", tone_with_harmonics(880, 2.2))
    write_wav("04_pitch_down_octave_220Hz.wav", tone_with_harmonics(220, 2.2))

    print("\nArpeggio (multi-note) — SampleBank / Renderer style")
    notes = [261.63, 329.63, 392.00, 523.25]  # C4 E4 G4 C5
    arpeggio = np.concatenate([tone_with_harmonics(f, 0.45) for f in notes])
    write_wav("05_arpeggio_Cmajor.wav", arpeggio)

    print("\nPhase-vocoder round-trip on arpeggio (+1 octave)")
    arp_up = pitch_shift(arpeggio, 2.0)
    assert len(arp_up) == len(arpeggio), (
        f"PitchShifter must preserve duration: "
        f"len_in={len(arpeggio)} len_out={len(arp_up)}"
    )
    write_wav("05b_arpeggio_Cmajor_octave_up.wav", arp_up)

    first_note = int(0.45 * SR)
    s0, s1 = first_note // 4, 3 * first_note // 4
    f_raw = dominant_freq(arpeggio[s0:s1])
    f_up = dominant_freq(arp_up[s0:s1])
    ratio = f_up / f_raw if f_raw > 0 else float("nan")
    print(f"    first-note F0: raw ~{f_raw:.1f} Hz, shifted ~{f_up:.1f} Hz, "
          f"ratio {ratio:.3f} (expected ~2.0)")
    assert abs(ratio - 2.0) < 0.12, (
        f"pitch ratio {ratio:.3f} is not approximately 2.0"
    )

    print("\nVocal-ish vibrato A/B")
    voc = vocalish()
    comp_voc = simple_feedforward_compressor(
        voc, SR, threshold_db=-20, ratio=3.5, makeup_db=3.0,
    )
    write_pair(
        "07_vocalish_raw.wav", voc,
        "08_vocalish_compressed.wav", comp_voc,
    )

    print("\nDone. Files are in:", OUT_DIR)
    print("Synthetic demos of *processing kinds* Eyesore supports. "
          "The real engine consumes real samples / voice-engine output.")


if __name__ == "__main__":
    main()